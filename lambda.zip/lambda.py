def lambda_handler_api_TF(event , context):
    print("hello world from Terraform - api gw lab")
    return "hello world from Terraform - api gw lab"